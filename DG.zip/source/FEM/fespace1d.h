// -----------------------------------------------------------------------------
//              DGmini, a minimal 1D discontinuous Galerkin solver
// -----------------------------------------------------------------------------
//
// Description: Finite element space class
//
// -----------------------------------------------------------------------------

#ifndef FESPACE1D_H
#define FESPACE1D_H

#include "Algebra/Vec.h"
#include "Algebra/Mat.h"
#include "FEM/quadrature1d.h"

// -----------------------------------------------------------------------------
// Description: Finite element space on one 1D element. This class stores all 
//              the info about the basis functions, quadrature and mass 
//              and stiffness matrices on reference element. 
// -----------------------------------------------------------------------------
class FESpace1D
{
  public:
    // -------------------------------------------------------------------------
    // Construction
    // -------------------------------------------------------------------------
    explicit FESpace1D(int p);

    // -------------------------------------------------------------------------
    // Access
    // -------------------------------------------------------------------------
    // Order of the basis functions
    int order() const { return p_;     }

    // Number of DoFs per reference element
    int DoFs()  const { return p_ + 1; }

    // Number of integration points
    int nip()   const { return quadrature_.nip(); }

    // DoF i basis function evaluated at integration point q
    double phi(int q, int i)  const { return phi_q_(q, i);  }

    // Derivative of DoF i basis function evaluated at integration point q
    double dphi(int q, int i) const { return dphi_q_(q, i); }

    // DoF i basis functions evaluated at left and right boundaries
    double phiLeft(int i)     const { return phi_left_[i];  }
    double phiRight(int i)    const { return phi_right_[i]; }

    // Quadrature rule on reference element
    const Quadrature1D& quadrature() const { return quadrature_; }
    
    // Mass and stiffness matrices on reference element
    const Mat& massMatrix()          const { return M_;          }
    const Mat& inverseMassMatrix()   const { return M_inv_;      }
    const Mat& stiffnessMatrix()     const { return K_;          }

    // -------------------------------------------------------------------------
    // Modification
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // Operations
    // -------------------------------------------------------------------------

  private:
    // -------------------------------------------------------------------------
    // Data
    // -------------------------------------------------------------------------
    int p_ = 0;

    Quadrature1D quadrature_;

    Vec phi_left_;
    Vec phi_right_;

    Mat phi_q_;
    Mat dphi_q_;
    Mat M_;
    Mat M_inv_;
    Mat K_;
};

#endif
